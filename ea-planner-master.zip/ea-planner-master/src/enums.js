export const STATUS = {
  traveling: 'Traveling for Business',
  office: 'Working From the Office',
  remote: 'Working Remotely',
  out: 'Out of Office',
}